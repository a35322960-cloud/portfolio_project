<?php
include 'db_connect.php';

$sql = "SELECT username, email FROM users LIMIT 1";
$result = $conn->query($sql);
$user = $result ? $result->fetch_assoc() : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Portfolio</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="logo">My Portfolio</div>
        <ul class="nav-links">
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About Me</a></li>
            <li><a href="#skills">Skills</a></li>
            <li><a href="#projects">Projects</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
        <button id="theme-btn" onclick="toggleDarkMode()">Dark Mode</button>
    </nav>

    <!-- Home Section -->
    <section id="home" class="hero">
        <h1>Welcome to My Website</h1>
        <p>Personal portfolio website showcasing my skills and projects.</p>
    </section>

    <!-- About Me Section -->
    <section id="about" class="section">
        <h2>About Me</h2>
        <?php if ($user): ?>
            <p>Hello! My name is <strong><?php echo htmlspecialchars($user['username']); ?></strong>.</p>
            <p>Email: <?php echo htmlspecialchars($user['email']); ?></p>
            <p>I am a software development student at the University of Hail, passionate about building dynamic web applications.</p>
        <?php else: ?>
            <p>Hello! I am a software development student at the University of Hail, passionate about building responsive web applications.</p>
        <?php endif; ?>
    </section>

    <!-- Skills Section -->
    <section id="skills" class="section">
        <h2>Skills</h2>
        <ul class="skills-list">
            <li>HTML & CSS</li>
            <li>JavaScript</li>
            <li>PHP & MySQL</li>
        </ul>
    </section>

    <!-- Projects Section -->
    <section id="projects" class="section">
        <h2>Projects</h2>
        <div class="project-card">
            <h3>Portfolio Website</h3>
            <p>A dynamic personal portfolio built using PHP, MySQL, and JavaScript.</p>
        </div>
    </section>

    <!-- Contact Form Section -->
    <section id="contact" class="section">
        <h2>Contact Form</h2>
        <form action="" method="POST">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <textarea name="message" placeholder="Your Message" required></textarea>
            <button type="submit">Send Message</button>
        </form>
    </section>

    <script src="script.js"></script>
</body>
</html>